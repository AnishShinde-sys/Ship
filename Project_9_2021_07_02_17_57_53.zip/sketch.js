var seaImg;
var shipImg;
function preload(){
  seaImg=loadImage("sea.png")
  shipImg=loadAnimation("ship-1.png","ship-2.png","ship-3.png","ship-4.png")
}


function setup(){
  createCanvas(400,400);
  sea=createSprite(100,100,100,100);
  sea.addImage("seaImg",seaImg);
  sea.scale=0.5
  ship=createSprite(140,170,130,120);
  ship.addAnimation("shipImg",shipImg);
  ship.scale=0.3
  sea.velocityX=-5
}

function draw() {
  background("blue");
if(sea.x< 0){
  sea.x = sea.width/7;
   } 
  drawSprites(); 
}